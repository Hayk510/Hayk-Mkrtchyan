﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp5
{
    public class Forms
    {   
        public Forms() { }
        public virtual void Create(int left, int top) { }
        public virtual void Move() { } 
    }
}
