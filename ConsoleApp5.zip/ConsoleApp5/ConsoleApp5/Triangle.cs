﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp5
{
    class Triangle : Forms
    {   
        private readonly int x;
        private int left;
        private int top;
        public Triangle(){ }
        public Triangle(int x)
        {
            this.x = x;
        }

        public override void Create(int left = 0, int top = 0)
        {
            Console.Clear();
            for (int i = 1; i <= x; i++)
            {
                Console.SetCursorPosition(left, top + i);
                for (int k = 1; k <= i; k++)
                {
                    if (i == k || k == 1 || i == x )
                    {
                        Console.Write("*");
                    } else
                    {
                        Console.Write(" ");
                    }
                }
                Console.WriteLine("");
            }
        }

        public override void Move()
        {
            while (true)
            {
                var command = Console.ReadKey().Key;

                switch (command)
                {
                    case ConsoleKey.DownArrow:
                        Create(left, top++);
                        break;
                    case ConsoleKey.UpArrow:
                        Create(left, top--);
                        break;
                    case ConsoleKey.LeftArrow:
                        Create(left--, top);
                        break;
                    case ConsoleKey.RightArrow:
                        Create(left++, top);
                        break;
                }
            }
        } 
    }
}
