﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp5
{
    class Rectangle : Forms
    {
        private readonly int height;
        private readonly int width;
        private int left;
        private int top;
        public Rectangle() { }
        public Rectangle(int x, int y)
        {
            height = x;
            width = y;
        }

        public override void Create(int left, int top)
        {
            Console.Clear();
            for(int i = 0; i < height; i++)
            {
                Console.SetCursorPosition(left, top + i);
                for (int j = 0; j < width; j++)
                {
                    if(i == 0 || j == 0 || j == width - 1 || i == height - 1)
                    {
                        Console.Write("*");
                    }
                    else
                    {
                        Console.Write(" ");
                    }
                }
                Console.WriteLine();
            }
        }

        public override void Move()
        {
            while (true)
            {
                var command = Console.ReadKey().Key;
                switch (command)
                {
                    case ConsoleKey.DownArrow:
                        Create(left, top++);
                        break;
                    case ConsoleKey.UpArrow:
                        Create(left, top--);
                        break;
                    case ConsoleKey.LeftArrow:
                        Create(left--, top);
                        break;
                    case ConsoleKey.RightArrow:
                        Create(left++, top);
                        break;
                }
            }
        }
    }
}
