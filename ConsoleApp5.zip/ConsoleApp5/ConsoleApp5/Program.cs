﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp5
{
    class Program
    {
        static void Main(string[] args)
        {
            Triangle tri = new Triangle(10);
            tri.Create();
            tri.Move();


            Console.ReadLine();
        }
    }
}
